<div class="bg-gradient-blue">
    <div class="container d-flex flex-row py-6">
        <form class="search-form w-100">
            <input wire:model.live.debounce.150ms="search" class="form-control rounded-2 shadow-lg"
                placeholder="Live Search and dont hit enter">
        </form>
    </div>
    <div class="container flex-row py-6 pt-1">
        

        <!--[if BLOCK]><![endif]--><?php if(!empty($values)): ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--[if BLOCK]><![endif]--><?php if($items->isNotEmpty()): ?>
                    <div class="card w-100 p-1 mb-2 ">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div wire:loading.inline-flex wire:target="search">
                                <p class=""></p> Loading...
                            </div>
                            <!--[if BLOCK]><![endif]--><?php if(isset($item->name_room)): ?>
                                <a href="<?php echo e(route('rooms.show', $item->id)); ?>">
                                    <p class="p-1 text-black"><?php echo e($item->name_room); ?>

                                    </p>
                                </a>
                            <?php elseif(isset($item->name)): ?>
                                <p class="p-1 text-black"><?php echo e($item->name); ?></p>
                            <?php elseif(isset($item->name_fasilitas)): ?>
                                <p class="p-1 text-black"><?php echo e($item->name_fasilitas); ?></p>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <span class="pb-1 pt-0 ms-2 text-black-50 fs-12"><?php echo e(ucfirst($type)); ?></span>
                    </div>
                <?php else: ?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <?php else: ?>
            <p class="fs-12">Cari Apa yang Kalian Suka !</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </div>
</div>
<?php /**PATH C:\laragon\www\hotel-rawa-pening-pratama\resources\views/livewire/searching.blade.php ENDPATH**/ ?>