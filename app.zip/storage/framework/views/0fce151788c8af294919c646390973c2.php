<footer class="bg-gray text-inverse">
    <div class="container py-7 py-md-9">
        <div class="row gy-6 gy-lg-0">
            <div class="col-lg-2 col-md-4">
                <div class="widget">
                    <img class="mb-1 p-1 w-auto" src="<?php echo e(asset('assets/img/logos/LogoHRPP.png')); ?>"
                        srcset="<?php echo e(asset('assets/img/logos/LogoHRPP.png 2x')); ?>" alt="" />

                </div>
                <!-- /.widget -->
            </div>
            <!-- /column -->
            <div class="col-md-4 col-lg-6 offset-lg-1">
                <div class="widget">
                </div>
                <h4 class="widget-title mb-3 text-blue-dark opacity-75">Hotel Rawa Pening Pratama</h4>


                
                <p class="mb-4 text-blue"> Jl. P. Diponegoro, RT.01/RW.01, Desa Kenteng, Bandungan,<br>
                    Kabupaten Semarang, Jawa Tengah 50655 <br>
                    Telp: <a class="text-blue" href=" <?php echo e($wa->url_profile ?? ''); ?> "> <?php echo e($wa->value ?? ''); ?></a> | WA
                    <a class="text-blue" href=" <?php echo e($wa2->url_profile ?? ''); ?> "> <?php echo e($wa2->value ?? ''); ?></a> | Email:
                    <?php echo e($email->value ?? ''); ?>

                </p>
                <nav class="nav fs-16 social">
                    <?php $__empty_1 = true; $__currentLoopData = $sosialapp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sapp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href=" <?php echo e($sapp->url_profile ?? ''); ?> " target="_blank"> <?php echo $sapp->icon ?? ''; ?></a>
                        

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>

                </nav>
            </div>

            <div class="col-md-4 col-lg-2 offset-lg-1">
                <div class="widget">
                    <a href="<?php echo e($wa->url_profile ?? ''); ?>" class="btn btn-red btn-sm text-uppercase text-nowrap">Book
                        Now</a>
                </div>
            </div>

        </div>

    </div>

</footer>

<div class="progress-wrap">
    <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
    </svg>
</div>
<?php /**PATH C:\laragon\www\hotel-rawa-pening-pratama\resources\views/layout/_footer.blade.php ENDPATH**/ ?>