<link rel="shortcut icon" href="<?php echo e(asset('assets/img/logos/LogoHRPP.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

<script src="https://c.webfontfree.com/c.js?f=BreuerText" type="text/javascript"></script>
<link rel="preload" href="<?php echo e(asset('assets/css/fonts/breuer.css')); ?>" as="style" onload="this.rel='stylesheet'">
<?php /**PATH C:\laragon\www\hotel-rawa-pening-pratama\resources\views/layout/_link.blade.php ENDPATH**/ ?>