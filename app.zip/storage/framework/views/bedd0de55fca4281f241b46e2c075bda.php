<script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/theme.js')); ?>"></script>
<?php /**PATH C:\laragon\www\hotel-rawa-pening-pratama\resources\views/layout/_script.blade.php ENDPATH**/ ?>