<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'Temukan hotel atau villa terbaik untuk liburan Anda.'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', 'hotel, villa, penginapan, liburan, akomodasi'); ?>">
    <meta name="author" content="Hotel Rawa Pening Pratama">
    <meta property="og:title" content="<?php echo $__env->yieldContent('meta_og_title', 'Hotel dan Villa Terbaik'); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('meta_og_description', 'Nikmati kenyamanan dan kemewahan di hotel atau villa pilihan kami.'); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:image" content="<?php echo e(asset('assets/img/logos/LogoHRPP.png')); ?>">
    <title>Hotel Rawa Pening Pratama</title>
    <?php echo $__env->yieldContent('meta'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo $__env->make('layout._link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('link-css'); ?>
</head>

<body>
    <div class="content-wrapper">
        <?php echo $__env->make('layout._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('breadcumb'); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('layout._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldPushContent('link-js'); ?>
    <?php echo $__env->make('layout._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\hotel-rawa-pening-pratama\resources\views/layout/app.blade.php ENDPATH**/ ?>