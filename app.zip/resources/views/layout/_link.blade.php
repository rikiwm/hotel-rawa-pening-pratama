<link rel="shortcut icon" href="{{ asset('assets/img/logos/LogoHRPP.png') }}">
<link rel="stylesheet" href="{{ asset('assets/css/plugins.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
{{-- <link rel="stylesheet" href="{{ asset('assets/css/colors/blue.css') }}"> --}}
<script src="https://c.webfontfree.com/c.js?f=BreuerText" type="text/javascript"></script>
<link rel="preload" href="{{ asset('assets/css/fonts/breuer.css') }}" as="style" onload="this.rel='stylesheet'">
