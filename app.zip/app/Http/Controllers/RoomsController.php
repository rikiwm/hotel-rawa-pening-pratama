<?php

namespace App\Http\Controllers;

use App\Models\Room;
use App\Models\RoomInclude;
use App\Models\Tag;
use Artesaos\SEOTools\Facades\JsonLd;
use Artesaos\SEOTools\Facades\OpenGraph;
use Artesaos\SEOTools\Facades\SEOMeta;
use Artesaos\SEOTools\Facades\TwitterCard;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;

class RoomsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $titel = 'Room and Villas';
        $rooms = Room::paginate(8);
        return view('frontend.rooms.index',compact('titel','rooms'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show($slug)
    {
        //
        $room = Room::where('slug',$slug)->firstOrFail();

        $t = $room->tag;
        $i = $room->room_fasilitas;
        $tagRoom = Tag::whereIn('id', $t)->get();
        $inc = RoomInclude::whereIn('id', $i)->get();

        SEOMeta::setTitle($room->seo_title ?: $room->name);
        SEOMeta::setDescription($room->seo_description ?: Str::limit($room->description, 160));
        SEOMeta::addMeta('penginapan:section', $room->typeRoom->name, 'property');
        // SEOMeta::addKeyword([$t]);
        OpenGraph::setTitle($room->seo_title ?: $room->name);
        OpenGraph::setDescription($room->seo_description ?: Str::limit($room->description, 160));
        OpenGraph::setUrl(url()->current());
        TwitterCard::setTitle($room->seo_title ?: $room->name);
        TwitterCard::setDescription($room->seo_description ?: Str::limit($room->description, 160));
        JsonLd::setTitle($room->seo_title ?: $room->name);
        JsonLd::setDescription($room->seo_description ?: Str::limit($room->description, 160));
        JsonLd::setUrl(url()->current());

        $images = $room->getMedia('rooms');

        $imageUrls = $images->map(function($image) {
            return $image->getUrl();
        });
        return view('frontend.rooms.show',compact('room','imageUrls','tagRoom','inc'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
