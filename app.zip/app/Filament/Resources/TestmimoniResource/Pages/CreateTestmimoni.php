<?php

namespace App\Filament\Resources\TestmimoniResource\Pages;

use App\Filament\Resources\TestmimoniResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTestmimoni extends CreateRecord
{
    protected static string $resource = TestmimoniResource::class;
}
