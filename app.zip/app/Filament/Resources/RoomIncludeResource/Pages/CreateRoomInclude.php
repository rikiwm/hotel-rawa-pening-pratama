<?php

namespace App\Filament\Resources\RoomIncludeResource\Pages;

use App\Filament\Resources\RoomIncludeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRoomInclude extends CreateRecord
{
    protected static string $resource = RoomIncludeResource::class;
}
